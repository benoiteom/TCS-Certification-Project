export class User{
    firstName: string="";
    lastName: string="";
    username: string="";
    password: string="";
    streetAddress: string="";
    city: string="";
    state: string="";
    zipCode: string="";
    userAccess: string="";

}