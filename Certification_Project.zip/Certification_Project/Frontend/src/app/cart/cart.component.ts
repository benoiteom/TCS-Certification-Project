import { analyzeAndValidateNgModules, ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  products: any = [];
  empty: boolean = true;
  total: any = 0;

  constructor() { }

  ngOnInit(): void {
    let cart = localStorage.getItem('cart');

    if (cart != "[]" && cart) {
      this.empty = false;
      for (let item of JSON.parse(cart)) {
        if (this.products.length == 0) {
          item.quantity = 1;
          this.products.push(item);
        } else {
          let flag = false;
          for (let product of this.products) {
            if (product._id == item._id) {
              product.quantity += 1;
              flag = true;
              break;
            }
          }
          if (!flag) {
            console.log("pushing item")
            item.quantity = 1;
            this.products.push(item);
          }
        }
        this.total += item.discountPrice;
      }
    }
  }

  remove(product: any) {
    let cart = localStorage.getItem('cart');
    if (cart) {
      let temp = JSON.parse(cart);
      console.log(temp)
      let arr = temp.filter(function(a: any) {
        console.log(a.name)
        console.log(product.name)
        return a.name !== product.name
      })
      if (arr.length == 0) {
        this.empty = true;
      }
      this.products.splice(this.products.indexOf(product), 1);
      localStorage.setItem('cart', JSON.stringify(arr));
    }
  }
}
